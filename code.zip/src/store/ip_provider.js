/**
 * Created by ASUS on 06-03-2019.
 */
function ip() {

        return "https://api-esi-to-find.esi.dz";

}
export default ip ;
