import React from 'react';

import '../my_ui.css'
import './actuality.css'

import Axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import ip from '../store/ip_provider';
import querystr from "querystring";
import Article from "./object";

import Instruction from './instruction';
import Lower from './phone_button'




function add(str){
    return (ip()+str);// api-ip http required
};

const style = {
    //width: "100%",

    backgroundSize :"cover",
    // backgroundColor : '#261326',
    backgroundColor: '#f9fbfb',
    textAlign: "center",
    position : 'static',
    minHeight:"100%",
    height:"100%",
    zIndex:"0",
    display:"flex",



};

const Article_style ={

    backgroundColor: '#f9fbfb',
    position :"inherits"

};


const end_style={
    minHeight: "60px",
    backgroundColor: "#2e3131",
    color: "white",
    padding: "20px",
    textAlign: "center"
};



class Actuality extends React.Component{
    constructor(props){
        super(props);

        this.state = {
            views:[],
            traslator:{},
            updated:false
        };
        this.gotten = [] ;

        this.height1 = 0 ;
        this.height2 = 0 ;
        this.on_update = false ;


        this.all_it=[];
        this.traslator = {} ;



        Axios.get(add('/api/types'), {params: {str:""}}).then((res) => {
                this.all_it=res.data;
                let tmpl = {} ;
                this.all_it.forEach((i)=>{
                    tmpl[i.info]=("glyphicon glyphicon-"+i.icon );
                });
                this.traslator = tmpl ;
                this.setState({updated:true,translator:tmpl});
            this.get_page();
            }
        ).catch((err) => {
            console.log(err)
        });

    }



    componentDidMount() {
        document.addEventListener("scroll",this.update_required);
    }

    update_required = event =>{
        this.height1 = ((window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight ) + window.pageYOffset );
        // console.log(this.height1);
        this.height2 = document.documentElement.scrollHeight ; ///height2 is static
        //  console.log(this.height2);
        if((this.height2<(this.height1+200))&&(!this.on_update)){
           this.on_update = true ;

            this.get_page();
            console.log("trigger");


        }
    };

    componentWillUnmount() {
        document.removeEventListener('scroll', this.update_required);
    }


    get_page = event =>{

        this.on_update = true;

        Axios.post(add("/api/actuality"), querystr.stringify({
            old_vals: JSON.stringify(this.gotten)

        }), {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        }).then((res)=>{
            console.log(res.data);
            res.data.forEach((i)=>{
               this.gotten.push(i._id)  ;

                this.on_update = false;
            });

            this.setState({views:[...this.state.views,...res.data]});


        }).catch((err)=>{console.log(err);
            this.on_update = false;});


    };



    render(){
        return <div className={"col-xs-12 zero_pad_v2"}>
            <div className={"col-xs-12"}>
                <h3> Trouvez tous les objects perdus et trouvés en temps Réel </h3>
                <div className={"col-xs-12 interline liner"}></div>
            </div>

            <div className={"col-xs-12 zero_pad_v2"} style={style}>
                <div className={"testing   zero_pad zero_pad_v2"} style={Article_style}>

                    {

                        ( this.state.views.map((i)=>{
                            return(
                                <div className={" col-md-4 col-sm-6 zero_pad"} key={i._id}>
                                    <Article style={Article_style} {...i} indepandante={true} icon={this.traslator[i.type]} />
                                </div>
                            );
                        }))

                    }



                </div>
                <div className={"bonus_right"}> <Instruction></Instruction> </div>

            </div>



            <div className={" col-xs-12"}  style={end_style}>
                ESI TO FIND `@2019
            </div>
            <Lower />



        </div>
    }


}
export default Actuality;