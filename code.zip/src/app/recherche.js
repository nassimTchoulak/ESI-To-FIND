import React from 'react';
import './recherche.css';
import '../my_ui.css';
import 'bootstrap/dist/css/bootstrap.min.css';

import Article from './object';

import Axios from 'axios';
import Lower from './phone_button'
import ip from '../store/ip_provider';

import {Redirect} from "react-router-dom";
import { BrowserRouter as Router, Route,  NavLink  } from "react-router-dom";
import Instruction from "./instruction";




const style = {
    //width: "100%",

     backgroundSize :"cover",
   // backgroundColor : '#261326',
    backgroundColor: '#f9fbfb',
    textAlign: "center",
    position : 'static',
    minHeight:"100%",
    height:"100%",
    zIndex:"0",
    display:"flex"



};

const Article_style ={

    backgroundColor: '#f9fbfb',
    position :"inherits"

};





function add(str){
    return (ip()+str);// api-ip http required
};


class recherche extends React.Component{
    constructor(props){
        super(props);

             console.log(this.props.location.search);
        const params = new URLSearchParams(this.props.location.search);
        const foo = params.get('type');
        const foo2 = params.get("date");

        let type_init="";
        if(foo!==null){
            type_init = foo;
        }
        let date_init="";
        if(foo2!==null){
            date_init = foo2 ;
        }



            this.toogle_nature =["trouvés","perdus","Tout" ];
            this.state= {nature:"Tout",

                visible_nature:false,

                visible_type:false,
                visible_place:false,
                display_type:[],
                display_place:[],
                type:type_init,
                place:"",
                views :[],
                date:date_init

            };



            this.allow_recherche=false;

            this.all_it=[];
            this.all_places=[];
            this.traslator = {};

            this.all_recherche = [] ;



        Axios.get(add('/api/types'), {params: {str:""}}).then((res) => {
            this.all_it=res.data;
            this.all_it.forEach((i)=>{
               this.traslator[i.info]=("glyphicon glyphicon-"+i.icon );
            });


            }
        ).catch((err) => {
            console.log(err)
        });
        Axios.get(add('/api/places'), {params: {str:""}}).then((res) => {
                this.all_places=res.data;
                console.log(this.all_places[0]);

            }
        ).catch((err) => {
            console.log(err)
        });
        this.props.history.push("/app/recherche");
        this.rechercher();
    }
    txt_change_type = event =>{
        let tmp = [];
        let str = event.target.value;
        if(/[!$%^&*()+|~=`{}\[\]:\/;<>?,.@#]/.test(str)){
            return 0;
        };
        let regt = new RegExp("^"+str,"i");
        this.all_it.forEach((i)=>{
            if((regt.test(i.info))&&(tmp.length<6)){
                tmp.push(i);
            }
        });


        this.setState({display_type:tmp,visible_type:true,type:event.target.value});
        this.allow_recherche=true;
    };

    txt_change_places = event =>{
        let tmp2 = [];
        let str2 = event.target.value;
        let regt2 = new RegExp("^"+str2,"i");
        this.all_places.forEach((i)=>{
            if((regt2.test(i))&&(tmp2.length<6)){
                tmp2.push(i)
            }
        });

        this.setState({display_place:tmp2,visible_place:true,place:event.target.value});
        this.allow_recherche=true;
    };
    go_to_poster = event =>{
       // document.querySelector("#type_recherche_valeur").focus();
        window.scrollTo(0,0);
        this.props.history.push("/app/poster");
    };
    select_type = event =>{
        let str = event.target.innerHTML;
        str = str.replace(/^ | $/,"");
        str = str.replace(/^ | $/,"");
        this.setState({visible_type:false,type:str});

    };
    select_place = event =>{
        let str = event.target.innerHTML;
        str = str.replace(/^ | $/,"");
        str = str.replace(/^ | $/,"");
        this.setState({visible_place:false,place:str});

    };
    date_change = event =>{

        this.setState({date:event.target.value });
        this.allow_recherche=true;
    };


    reduce_visible = event =>{
       this.setState({visible_type:false,visible_place:false});
    };


    clickhandler_nature = event =>{
        let val = event.target.innerHTML;
        event.stopPropagation();
       // console.log(val);
      this.setState({nature:val,visible_nature:false,visible_place:false,visible_type:false});
        this.allow_recherche=true;

    };
    rechercher = event =>{
     // alert(this.date+" | "+this.state.nature+" | "+this.state.type+" | "+this.state.place);
        let dict ={type:this.state.type,lieu:this.state.place};
                // filter need to be added

            if(this.state.nature==="perdus"){
                dict.nature="perdu";
            }
            else{
                if(this.state.nature==="trouvés"){
                    dict.nature="trouve";
                }
            }


        if(this.state.date===""){

        }
        else{
            dict.date= this.state.date;
        }
      Axios.get(add('/api/data'),{params:dict}).then(
          (res)=>{

                let views_ls =[];

              console.log(res.data);

              this.all_recherche = res.data ;

              res.data.forEach((i,itr)=>{
                if(itr<18) {
                    views_ls.push(i);
                }
              });

              this.setState({views:views_ls});



          }
      ).catch( (err)=> {
            console.log(err);
          }
      );


        this.allow_recherche=false;
    };

    show_nature = event =>{
      this.setState({visible_nature:true});
     // this.allow_recherche=true;
    };


    componentDidMount() {
        document.addEventListener("scroll",this.update_required);
    }

    update_required = event =>{
        this.height1 = ((window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight ) + window.pageYOffset );

        this.height2 = document.documentElement.scrollHeight ; ///height2 is static

        if((this.height2<(this.height1+200))&&(!this.on_update)){


            let yet = [];
            console.log("trigger");
            this.state.views.forEach((i)=>{
               yet.push(i);
            });

            let itr =0;

           this.all_recherche.forEach((t)=>{
               if((this.state.views.indexOf(t)===-1)&&(itr<18)){
                   yet.push(t);
                   itr++ ;
               }
           });

           if(this.state.views.length===this.all_recherche.length){
               // end update
           }

            this.setState({views:yet});



        }
    };

    componentWillUnmount() {
        document.removeEventListener('scroll', this.update_required);
    }




    render(){
        return (
            <div className={" col-xs-12 zero_pad_v2"} >
                <div className={"stick2 col-xs-12"} onClick={this.reduce_visible}>



                    <div className={"col-md-2"} onClick={this.show_nature}>


                          <div className={"col-sm-12 hidden-xs"}> nature des objects  </div>
                           <div className={"my_button_v3 col-xs-12"}>  {this.state.nature} </div>
                           <div id={"holder"} className={"col-xs-12 list"}>

                        {
                            this.state.visible_nature &&( this.toogle_nature.map((i)=>{

                                return (<div onClick={this.clickhandler_nature} className={" list_item col-xs-12 "} key={i.toString()} >
                                    {i}
                                </div>);
                            }) )

                        }

                        </div>
                    </div>

                    <div className={"col-md-3"}>
                        <div className={"col-xs-12"}> types d'objects </div>

                         <input type={"text"} autoComplete={"off"} id={"type_recherche_valeur"} placeholder={"Mon objects"} value={this.state.type} onChange={this.txt_change_type} className={"my_text_box_v2 col-xs-offset-1 col-xs-pull-1 col-xs-9 adapt_type"} />

                        <div className={"col-xs-12 list_hold"}>
                            <div className={"col-xs-10 list"}>
                                {
                                    this.state.visible_type && (this.state.display_type.map((i)=>{
                                        return (<div className={"list_item col-xs-11 col-xs-offset-1"} key={i.info.toString()}>
                                            <div className={"glyphicon glyphicon-"+i.icon+"  span col-xs-1"}> </div>
                                            <div onClick={this.select_type} className={"col-md-5 col-xs-offset-1 inc"} > {i.info.toString()} </div>

                                        </div>);
                                    }))
                                }
                            </div>
                        </div>
                    </div>


                    <div className={"col-md-2 col-md-offset-1"}>
                        <div className={"col-xs-12"}> Date </div>
                        <input type={"date"} onChange={this.date_change} value={this.state.date} autoComplete={"off"} className={"my_text_box_v2 col-xs-offset-1 col-xs-9 col-xs-pull-1 adapt_type"} />
                        <div className={"col-xs-12"}> </div>
                    </div>


                    <div className={"col-md-2 hidden-xs"}>
                        <div className={"col-xs-12"}> Lieu </div>
                        <input type={"text"} placeholder={"place"} value={this.state.place} onChange={this.txt_change_places} autoComplete={"off"}  className={"my_text_box_v2 col-xs-offset-1 col-xs-11 adapt_type"} />
                        <div className={"col-xs-12 list_hold"}>
                            <div className={"col-xs-12 list"}>

                                {
                                    this.state.visible_place && (this.state.display_place.map((i)=>{
                                        return ( <div className={"list_item col-xs-11 col-xs-offset-1"} key={i.toString()}>

                                                <div className={"glyphicon glyphicon-map-marker  span col-xs-1"}> </div>
                                                <div onClick={this.select_place} className={"col-md-5 col-xs-offset-1 inc"} > {i.toString()} </div>

                                            </div>
                                                );

                                    } ))


                                }

                            </div>
                        </div>
                    </div>



                    <div className={"col-md-2 "}>

                        <input type={"button"} onClick={this.rechercher} value={" Recherche"} disabled={!this.allow_recherche} className={" col-xs-offset-1 col-xs-11 adapt_recherche"} />


                    </div>



                </div>

             <div className={"col-xs-12 zero_pad_v2"} style={style}>
            <div className={" recherche testing zero_pad zero_pad_v2"} style={Article_style}>

                {

                    ( this.state.views.map((i)=>{
                        return(
                            <div className={"col-md-4 zero_pad"} key={i._id}>
                                <Article style={Article_style} {...i}  icon={this.traslator[i.type]} />
                            </div>
                        );
                    }))

                }
                {
                    (this.state.views.length===0)&&<div className={"col-xs-12 interline"}> <h3>Aucun Résultat ne correspandant à votre recherche</h3></div>
                }



                </div>

                 <div className={"bonus_right"}> <Instruction></Instruction> </div>

             </div>


                <div className={" col-xs-12 "} >
                    <div className={"col-xs-offset-3 col-xs-6 hidden-xs"}> <div onClick={this.go_to_poster} className={"my_button_v2"} > Poster un nouveau Object</div> </div>
                </div>

                <div className={" col-xs-12 end_style "} >
                    ESI TO FIND `@2019
                </div>
                <Lower />


        </div>);
    }


}
export default recherche ;